from BK_UsersCR import app
from BK_UsersCR.controllers import users_controller


if __name__=='__main__':
    app.run(debug=True)

