class BankAccount:
    all_accounts = []
    # don't forget to add some default values for these parameters!
    def __init__(self, int_rate, balance): 
        # your code here! (remember, instance attributes go here)
        self.int_rate = int_rate
        self.balance = balance
        BankAccount.all_accounts.append(self)
        # don't worry about user info here; we'll involve the User class soon
    def deposit(self, amount):
        # your code here
        self.balance += amount
        return self
    def withdraw(self, amount):
        # your code here
        if self.balance <= 0:
            print("Insufficient funds: Charging a $5 fee")
            self.balance -= 5
        else:
            self.balance -= amount
            
        return self
    def display_account_info(self):
        # your code here
        print(f"Interest Rate: {self.int_rate}, Balance: {self.balance}")
    def yield_interest(self):
        if self.balance > 0:
            self.balance *= (1+self.int_rate)
        return self
        # your code here
    def __repr__(self):
        return f"Interest Rate: {self.int_rate}, Balance: {self.balance}"

brandon = BankAccount(.20, 1000)
chris = BankAccount(.15, 0)

brandon.deposit(300).deposit(200).deposit(300).withdraw(400).yield_interest()
chris.deposit(1000).deposit(300).withdraw(300).withdraw(1000).withdraw(200).withdraw(200).yield_interest()

for one_account in BankAccount.all_accounts:
    one_account.display_account_info()
