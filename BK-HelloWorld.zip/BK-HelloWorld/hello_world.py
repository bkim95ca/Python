print("Hello World") #1
my_name = 'Brandon'

print("Hello", my_name) #2a
print("Hello " + my_name) #2b

favorite_num = "16"
print("Hello", favorite_num) #3a
print("Hello " + favorite_num) #3b

food_one = "potatoes"
food_two = "burgers"

print("I love to eat {} and {}".format(food_one, food_two)) #4a
print(f"I love to eat {food_one} and {food_two}") #4b